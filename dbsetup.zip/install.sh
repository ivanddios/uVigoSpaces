
#Instalador de permisos

chmod 777 et3_iu
chmod 777 et3_iu/Views
chmod 777 et3_iu/Controllers
chmod 777 et3_iu/Documents
exit
