
<html lang="es">

    <head></br>
        ----- ----- ----- //   INSTALADOR DE LA BASE DE DATOS   // ----- ----- ----- </br></br>
        <meta charset="UTF-8">
    </head>

    <body>
        <p> [ Introduzca el Usuario y Contraseña root de la base de datos ] </p>
        
        <form action="./et3_iu/install_finish.php" method="post">

            <p>Usuario <input type="text" name="usuario"></p>
            <p>Contraseña <input type="password" name="password"></p>
            <p><input type="submit"> <input type="reset"></p>
            <p></br></br>----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- </p>
        </form>

    </body>

</html>



